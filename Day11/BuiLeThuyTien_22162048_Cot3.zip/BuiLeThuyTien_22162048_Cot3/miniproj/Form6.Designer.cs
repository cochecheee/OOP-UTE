﻿namespace miniproj
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btn_sapxep = new System.Windows.Forms.Button();
            this.cb_timtheo = new System.Windows.Forms.ComboBox();
            this.cb_sapxep = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_gia = new System.Windows.Forms.TextBox();
            this.txt_nhaxuatban = new System.Windows.Forms.TextBox();
            this.txt_isbn = new System.Windows.Forms.TextBox();
            this.txt_tacgia = new System.Windows.Forms.TextBox();
            this.txt_tensach = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_ban = new System.Windows.Forms.TextBox();
            this.btn_ban = new System.Windows.Forms.Button();
            this.miniprojectDataSet5 = new miniproj.miniprojectDataSet5();
            this.bookBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bookTableAdapter = new miniproj.miniprojectDataSet5TableAdapters.bookTableAdapter();
            this.isbnDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tensachDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tacgiaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nhaxuatbanDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.giaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.miniprojectDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_sapxep
            // 
            this.btn_sapxep.Location = new System.Drawing.Point(151, 368);
            this.btn_sapxep.Name = "btn_sapxep";
            this.btn_sapxep.Size = new System.Drawing.Size(117, 25);
            this.btn_sapxep.TabIndex = 37;
            this.btn_sapxep.Text = "Sắp xếp giá";
            this.btn_sapxep.UseVisualStyleBackColor = true;
            this.btn_sapxep.Click += new System.EventHandler(this.btn_sapxep_Click);
            // 
            // cb_timtheo
            // 
            this.cb_timtheo.FormattingEnabled = true;
            this.cb_timtheo.Items.AddRange(new object[] {
            "Tên sách",
            "Tác giả",
            "ISBN",
            "Nhà xuất bản",
            "Giá"});
            this.cb_timtheo.Location = new System.Drawing.Point(151, 35);
            this.cb_timtheo.Name = "cb_timtheo";
            this.cb_timtheo.Size = new System.Drawing.Size(160, 24);
            this.cb_timtheo.TabIndex = 36;
            this.cb_timtheo.SelectedIndexChanged += new System.EventHandler(this.cb_timtheo_SelectedIndexChanged);
            // 
            // cb_sapxep
            // 
            this.cb_sapxep.FormattingEnabled = true;
            this.cb_sapxep.Items.AddRange(new object[] {
            "Tăng",
            "Giảm"});
            this.cb_sapxep.Location = new System.Drawing.Point(151, 322);
            this.cb_sapxep.Name = "cb_sapxep";
            this.cb_sapxep.Size = new System.Drawing.Size(160, 24);
            this.cb_sapxep.TabIndex = 35;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(57, 325);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 16);
            this.label6.TabIndex = 33;
            this.label6.Text = "Sắp xếp";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(57, 279);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(28, 16);
            this.label7.TabIndex = 32;
            this.label7.Text = "Giá";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(57, 239);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 16);
            this.label5.TabIndex = 34;
            this.label5.Text = "Nhà xuất bản";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(57, 191);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 16);
            this.label4.TabIndex = 31;
            this.label4.Text = "ISBN";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(57, 142);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 16);
            this.label3.TabIndex = 30;
            this.label3.Text = "Tác giả";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(57, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 16);
            this.label2.TabIndex = 29;
            this.label2.Text = "Tên sách";
            // 
            // txt_gia
            // 
            this.txt_gia.Location = new System.Drawing.Point(151, 279);
            this.txt_gia.Name = "txt_gia";
            this.txt_gia.ReadOnly = true;
            this.txt_gia.Size = new System.Drawing.Size(160, 22);
            this.txt_gia.TabIndex = 27;
            this.txt_gia.TextChanged += new System.EventHandler(this.txt_gia_TextChanged);
            // 
            // txt_nhaxuatban
            // 
            this.txt_nhaxuatban.Location = new System.Drawing.Point(151, 236);
            this.txt_nhaxuatban.Name = "txt_nhaxuatban";
            this.txt_nhaxuatban.ReadOnly = true;
            this.txt_nhaxuatban.Size = new System.Drawing.Size(160, 22);
            this.txt_nhaxuatban.TabIndex = 26;
            this.txt_nhaxuatban.TextChanged += new System.EventHandler(this.txt_nhaxuatban_TextChanged);
            // 
            // txt_isbn
            // 
            this.txt_isbn.Location = new System.Drawing.Point(151, 188);
            this.txt_isbn.Name = "txt_isbn";
            this.txt_isbn.ReadOnly = true;
            this.txt_isbn.Size = new System.Drawing.Size(160, 22);
            this.txt_isbn.TabIndex = 25;
            this.txt_isbn.TextChanged += new System.EventHandler(this.txt_isbn_TextChanged);
            // 
            // txt_tacgia
            // 
            this.txt_tacgia.Location = new System.Drawing.Point(151, 142);
            this.txt_tacgia.Name = "txt_tacgia";
            this.txt_tacgia.ReadOnly = true;
            this.txt_tacgia.Size = new System.Drawing.Size(160, 22);
            this.txt_tacgia.TabIndex = 24;
            this.txt_tacgia.TextChanged += new System.EventHandler(this.txt_tacgia_TextChanged);
            // 
            // txt_tensach
            // 
            this.txt_tensach.Location = new System.Drawing.Point(151, 89);
            this.txt_tensach.Name = "txt_tensach";
            this.txt_tensach.ReadOnly = true;
            this.txt_tensach.Size = new System.Drawing.Size(160, 22);
            this.txt_tensach.TabIndex = 28;
            this.txt_tensach.TextChanged += new System.EventHandler(this.txt_tensach_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(54, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 16);
            this.label1.TabIndex = 23;
            this.label1.Text = "Tìm theo";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.isbnDataGridViewTextBoxColumn,
            this.tensachDataGridViewTextBoxColumn,
            this.tacgiaDataGridViewTextBoxColumn,
            this.nhaxuatbanDataGridViewTextBoxColumn,
            this.giaDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.bookBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(367, 35);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(402, 311);
            this.dataGridView1.TabIndex = 38;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(367, 376);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(38, 16);
            this.label8.TabIndex = 39;
            this.label8.Text = "ISBN";
            // 
            // txt_ban
            // 
            this.txt_ban.Location = new System.Drawing.Point(443, 373);
            this.txt_ban.Name = "txt_ban";
            this.txt_ban.Size = new System.Drawing.Size(218, 22);
            this.txt_ban.TabIndex = 40;
            // 
            // btn_ban
            // 
            this.btn_ban.Location = new System.Drawing.Point(687, 372);
            this.btn_ban.Name = "btn_ban";
            this.btn_ban.Size = new System.Drawing.Size(82, 25);
            this.btn_ban.TabIndex = 37;
            this.btn_ban.Text = "Bán";
            this.btn_ban.UseVisualStyleBackColor = true;
            this.btn_ban.Click += new System.EventHandler(this.btn_ban_Click);
            // 
            // miniprojectDataSet5
            // 
            this.miniprojectDataSet5.DataSetName = "miniprojectDataSet5";
            this.miniprojectDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bookBindingSource
            // 
            this.bookBindingSource.DataMember = "book";
            this.bookBindingSource.DataSource = this.miniprojectDataSet5;
            // 
            // bookTableAdapter
            // 
            this.bookTableAdapter.ClearBeforeFill = true;
            // 
            // isbnDataGridViewTextBoxColumn
            // 
            this.isbnDataGridViewTextBoxColumn.DataPropertyName = "isbn";
            this.isbnDataGridViewTextBoxColumn.HeaderText = "isbn";
            this.isbnDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.isbnDataGridViewTextBoxColumn.Name = "isbnDataGridViewTextBoxColumn";
            this.isbnDataGridViewTextBoxColumn.Width = 125;
            // 
            // tensachDataGridViewTextBoxColumn
            // 
            this.tensachDataGridViewTextBoxColumn.DataPropertyName = "Tensach";
            this.tensachDataGridViewTextBoxColumn.HeaderText = "Tensach";
            this.tensachDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.tensachDataGridViewTextBoxColumn.Name = "tensachDataGridViewTextBoxColumn";
            this.tensachDataGridViewTextBoxColumn.Width = 125;
            // 
            // tacgiaDataGridViewTextBoxColumn
            // 
            this.tacgiaDataGridViewTextBoxColumn.DataPropertyName = "Tacgia";
            this.tacgiaDataGridViewTextBoxColumn.HeaderText = "Tacgia";
            this.tacgiaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.tacgiaDataGridViewTextBoxColumn.Name = "tacgiaDataGridViewTextBoxColumn";
            this.tacgiaDataGridViewTextBoxColumn.Width = 125;
            // 
            // nhaxuatbanDataGridViewTextBoxColumn
            // 
            this.nhaxuatbanDataGridViewTextBoxColumn.DataPropertyName = "Nhaxuatban";
            this.nhaxuatbanDataGridViewTextBoxColumn.HeaderText = "Nhaxuatban";
            this.nhaxuatbanDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.nhaxuatbanDataGridViewTextBoxColumn.Name = "nhaxuatbanDataGridViewTextBoxColumn";
            this.nhaxuatbanDataGridViewTextBoxColumn.Width = 125;
            // 
            // giaDataGridViewTextBoxColumn
            // 
            this.giaDataGridViewTextBoxColumn.DataPropertyName = "Gia";
            this.giaDataGridViewTextBoxColumn.HeaderText = "Gia";
            this.giaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.giaDataGridViewTextBoxColumn.Name = "giaDataGridViewTextBoxColumn";
            this.giaDataGridViewTextBoxColumn.Width = 125;
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txt_ban);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btn_ban);
            this.Controls.Add(this.btn_sapxep);
            this.Controls.Add(this.cb_timtheo);
            this.Controls.Add(this.cb_sapxep);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_gia);
            this.Controls.Add(this.txt_nhaxuatban);
            this.Controls.Add(this.txt_isbn);
            this.Controls.Add(this.txt_tacgia);
            this.Controls.Add(this.txt_tensach);
            this.Controls.Add(this.label1);
            this.Name = "Form6";
            this.Text = "Form6";
            this.Load += new System.EventHandler(this.Form6_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.miniprojectDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_sapxep;
        private System.Windows.Forms.ComboBox cb_timtheo;
        private System.Windows.Forms.ComboBox cb_sapxep;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_gia;
        private System.Windows.Forms.TextBox txt_nhaxuatban;
        private System.Windows.Forms.TextBox txt_isbn;
        private System.Windows.Forms.TextBox txt_tacgia;
        private System.Windows.Forms.TextBox txt_tensach;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_ban;
        private System.Windows.Forms.Button btn_ban;
        private miniprojectDataSet5 miniprojectDataSet5;
        private System.Windows.Forms.BindingSource bookBindingSource;
        private miniprojectDataSet5TableAdapters.bookTableAdapter bookTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn isbnDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tensachDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tacgiaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nhaxuatbanDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn giaDataGridViewTextBoxColumn;
    }
}