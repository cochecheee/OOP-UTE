﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace miniproj
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        bookDataContext db = new bookDataContext();
        private void Form6_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'miniprojectDataSet5.book' table. You can move, or remove it, as needed.
            this.bookTableAdapter.Fill(this.miniprojectDataSet5.book);

            var list = (from s in db.books select s).ToList();
            dataGridView1.DataSource = list;
        }

        private void cb_timtheo_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cb_timtheo.SelectedIndex == 0)
                {
                    txt_tensach.Clear();
                    txt_tacgia.Clear();
                    txt_isbn.Clear();
                    txt_nhaxuatban.Clear();
                    txt_gia.Clear();

                    txt_tensach.ReadOnly = false;
                    txt_gia.ReadOnly = true;
                    txt_isbn.ReadOnly = true;
                    txt_nhaxuatban.ReadOnly = true;
                    txt_gia.ReadOnly = true;

                }
                else if (cb_timtheo.SelectedIndex == 1)
                {
                    txt_tensach.Clear();
                    txt_tacgia.Clear();
                    txt_isbn.Clear();
                    txt_nhaxuatban.Clear();
                    txt_gia.Clear();

                    txt_tensach.ReadOnly = true;
                    txt_tacgia.ReadOnly = false;
                    txt_isbn.ReadOnly = true;
                    txt_nhaxuatban.ReadOnly = true;
                    txt_gia.ReadOnly = true;

                }
                else if (cb_timtheo.SelectedIndex == 2)
                {
                    txt_tensach.Clear();
                    txt_tacgia.Clear();
                    txt_isbn.Clear();
                    txt_nhaxuatban.Clear();
                    txt_gia.Clear();

                    txt_tensach.ReadOnly = true;
                    txt_tacgia.ReadOnly = true;
                    txt_isbn.ReadOnly = false;
                    txt_nhaxuatban.ReadOnly = true;
                    txt_gia.ReadOnly = true;

                }
                else if (cb_timtheo.SelectedIndex == 3)
                {
                    txt_tensach.Clear();
                    txt_tacgia.Clear();
                    txt_isbn.Clear();
                    txt_nhaxuatban.Clear();
                    txt_gia.Clear();

                    txt_tensach.ReadOnly = true;
                    txt_tacgia.ReadOnly = true;
                    txt_isbn.ReadOnly = true;
                    txt_nhaxuatban.ReadOnly = false;
                    txt_gia.ReadOnly = true;

                }
                else if (cb_timtheo.SelectedIndex == 4)
                {
                    txt_tensach.Clear();
                    txt_tacgia.Clear();
                    txt_isbn.Clear();
                    txt_nhaxuatban.Clear();
                    txt_gia.Clear();

                    txt_tensach.ReadOnly = true;
                    txt_tacgia.ReadOnly = true;
                    txt_isbn.ReadOnly = true;
                    txt_nhaxuatban.ReadOnly = true;
                    txt_gia.ReadOnly = false;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btn_sapxep_Click(object sender, EventArgs e)
        {
            try
            {
                if (cb_sapxep.SelectedIndex == -1)
                {
                    MessageBox.Show("Vui lòng nhấp chọn sắp xếp tăng hay giảm");
                    return;
                }
                else if (cb_sapxep.SelectedIndex == 0)
                {
                    //tăng
                    var list = db.books.OrderBy(s => Convert.ToInt32(s.Gia)).ToList();
                    dataGridView1.DataSource = list;
                }
                else if (cb_sapxep.SelectedIndex == 1)
                {
                    //giảm
                    var list = db.books.OrderByDescending(s => Convert.ToInt32(s.Gia)).ToList();
                    dataGridView1.DataSource = list;
                }
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txt_tensach_TextChanged(object sender, EventArgs e)
        {
            var list = (from s in db.books where s.Tensach.Contains(txt_tensach.Text) select s).ToList();
            dataGridView1.DataSource = list;
        }

        private void txt_tacgia_TextChanged(object sender, EventArgs e)
        {
            var list = (from s in db.books where s.Tacgia.Contains(txt_tacgia.Text) select s).ToList();
            dataGridView1.DataSource = list;
        }

        private void txt_isbn_TextChanged(object sender, EventArgs e)
        {
            var list = (from s in db.books where s.isbn.Contains(txt_isbn.Text) select s).ToList();
            dataGridView1.DataSource = list;
        }

        private void txt_nhaxuatban_TextChanged(object sender, EventArgs e)
        {
            var list = (from s in db.books where s.Nhaxuatban.Contains(txt_nhaxuatban.Text) select s).ToList();
            dataGridView1.DataSource = list;
        }

        private void txt_gia_TextChanged(object sender, EventArgs e)
        {
            var list = (from s in db.books where s.Gia.Contains(txt_gia.Text) select s).ToList();
            dataGridView1.DataSource = list;
        }

        private void btn_ban_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_ban.Text))
            {
                MessageBox.Show("Không có điện thoại này trong hãng.");
                return;
            }

            try
            {
                var list = db.books.Where(s => s.isbn == txt_ban.Text).FirstOrDefault();

                if (list != null)
                {
                    bookstore book = new bookstore();
                    book.Tensach = list.Tensach;
                    book.Tacgia = list.Tacgia;
                    book.isbn = list.isbn;
                    book.Nhaxuatban = list.Nhaxuatban;
                    book.Gia = list.Gia;
                    book.Thangban = DateTime.Now.Month.ToString();

                    bookstoreDataContext bs = new bookstoreDataContext();
                    bs.bookstores.InsertOnSubmit(book);
                    db.books.DeleteOnSubmit(list);

                    bs.SubmitChanges();
                    db.SubmitChanges();

                    Form6_Load(sender, e);
                }
                else
                {
                    MessageBox.Show("Không có điện thoại này trong hãng.");
                    return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
