﻿namespace miniproj
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.soseriDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tenthietbiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mausachDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.namsanxuatDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.giaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.devicesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.miniprojectDataSet4 = new miniproj.miniprojectDataSet4();
            this.btn_ban = new System.Windows.Forms.Button();
            this.btn_sapxep = new System.Windows.Forms.Button();
            this.cb_timtheo = new System.Windows.Forms.ComboBox();
            this.cb_sapxep = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_gia = new System.Windows.Forms.TextBox();
            this.txt_soseri = new System.Windows.Forms.TextBox();
            this.txt_mausac = new System.Windows.Forms.TextBox();
            this.txt_namsanxuat = new System.Windows.Forms.TextBox();
            this.txt_tenthietbi = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.devicesTableAdapter = new miniproj.miniprojectDataSet4TableAdapters.devicesTableAdapter();
            this.txt_ban = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.devicesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.miniprojectDataSet4)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.soseriDataGridViewTextBoxColumn,
            this.tenthietbiDataGridViewTextBoxColumn,
            this.mausachDataGridViewTextBoxColumn,
            this.namsanxuatDataGridViewTextBoxColumn,
            this.giaDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.devicesBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(364, 40);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(406, 311);
            this.dataGridView1.TabIndex = 24;
            // 
            // soseriDataGridViewTextBoxColumn
            // 
            this.soseriDataGridViewTextBoxColumn.DataPropertyName = "Soseri";
            this.soseriDataGridViewTextBoxColumn.HeaderText = "Soseri";
            this.soseriDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.soseriDataGridViewTextBoxColumn.Name = "soseriDataGridViewTextBoxColumn";
            this.soseriDataGridViewTextBoxColumn.Width = 125;
            // 
            // tenthietbiDataGridViewTextBoxColumn
            // 
            this.tenthietbiDataGridViewTextBoxColumn.DataPropertyName = "Tenthietbi";
            this.tenthietbiDataGridViewTextBoxColumn.HeaderText = "Tenthietbi";
            this.tenthietbiDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.tenthietbiDataGridViewTextBoxColumn.Name = "tenthietbiDataGridViewTextBoxColumn";
            this.tenthietbiDataGridViewTextBoxColumn.Width = 125;
            // 
            // mausachDataGridViewTextBoxColumn
            // 
            this.mausachDataGridViewTextBoxColumn.DataPropertyName = "Mausach";
            this.mausachDataGridViewTextBoxColumn.HeaderText = "Mausach";
            this.mausachDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.mausachDataGridViewTextBoxColumn.Name = "mausachDataGridViewTextBoxColumn";
            this.mausachDataGridViewTextBoxColumn.Width = 125;
            // 
            // namsanxuatDataGridViewTextBoxColumn
            // 
            this.namsanxuatDataGridViewTextBoxColumn.DataPropertyName = "Namsanxuat";
            this.namsanxuatDataGridViewTextBoxColumn.HeaderText = "Namsanxuat";
            this.namsanxuatDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.namsanxuatDataGridViewTextBoxColumn.Name = "namsanxuatDataGridViewTextBoxColumn";
            this.namsanxuatDataGridViewTextBoxColumn.Width = 125;
            // 
            // giaDataGridViewTextBoxColumn
            // 
            this.giaDataGridViewTextBoxColumn.DataPropertyName = "Gia";
            this.giaDataGridViewTextBoxColumn.HeaderText = "Gia";
            this.giaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.giaDataGridViewTextBoxColumn.Name = "giaDataGridViewTextBoxColumn";
            this.giaDataGridViewTextBoxColumn.Width = 125;
            // 
            // devicesBindingSource
            // 
            this.devicesBindingSource.DataMember = "devices";
            this.devicesBindingSource.DataSource = this.miniprojectDataSet4;
            // 
            // miniprojectDataSet4
            // 
            this.miniprojectDataSet4.DataSetName = "miniprojectDataSet4";
            this.miniprojectDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btn_ban
            // 
            this.btn_ban.Location = new System.Drawing.Point(667, 367);
            this.btn_ban.Name = "btn_ban";
            this.btn_ban.Size = new System.Drawing.Size(103, 37);
            this.btn_ban.TabIndex = 23;
            this.btn_ban.Text = "Bán";
            this.btn_ban.UseVisualStyleBackColor = true;
            this.btn_ban.Click += new System.EventHandler(this.btn_ban_Click);
            // 
            // btn_sapxep
            // 
            this.btn_sapxep.Location = new System.Drawing.Point(128, 373);
            this.btn_sapxep.Name = "btn_sapxep";
            this.btn_sapxep.Size = new System.Drawing.Size(88, 25);
            this.btn_sapxep.TabIndex = 22;
            this.btn_sapxep.Text = "Sắp xếp";
            this.btn_sapxep.UseVisualStyleBackColor = true;
            this.btn_sapxep.Click += new System.EventHandler(this.btn_sapxep_Click);
            // 
            // cb_timtheo
            // 
            this.cb_timtheo.FormattingEnabled = true;
            this.cb_timtheo.Items.AddRange(new object[] {
            "Tên thiết bị",
            "Năm sản xuất",
            "Màu sác",
            "Số seri",
            "Giá"});
            this.cb_timtheo.Location = new System.Drawing.Point(128, 40);
            this.cb_timtheo.Name = "cb_timtheo";
            this.cb_timtheo.Size = new System.Drawing.Size(160, 24);
            this.cb_timtheo.TabIndex = 21;
            this.cb_timtheo.SelectedIndexChanged += new System.EventHandler(this.cb_timtheo_SelectedIndexChanged);
            // 
            // cb_sapxep
            // 
            this.cb_sapxep.FormattingEnabled = true;
            this.cb_sapxep.Items.AddRange(new object[] {
            "Tăng",
            "Giảm"});
            this.cb_sapxep.Location = new System.Drawing.Point(128, 327);
            this.cb_sapxep.Name = "cb_sapxep";
            this.cb_sapxep.Size = new System.Drawing.Size(160, 24);
            this.cb_sapxep.TabIndex = 20;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(34, 330);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 16);
            this.label6.TabIndex = 18;
            this.label6.Text = "Sắp xếp";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(34, 284);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(28, 16);
            this.label7.TabIndex = 17;
            this.label7.Text = "Giá";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(34, 244);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 16);
            this.label5.TabIndex = 19;
            this.label5.Text = "Số seri";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(34, 196);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 16);
            this.label4.TabIndex = 16;
            this.label4.Text = "Màu sắc";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(34, 147);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 16);
            this.label3.TabIndex = 15;
            this.label3.Text = "Năm sản xuất";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 16);
            this.label2.TabIndex = 14;
            this.label2.Text = "Tên thiết bị";
            // 
            // txt_gia
            // 
            this.txt_gia.Location = new System.Drawing.Point(128, 284);
            this.txt_gia.Name = "txt_gia";
            this.txt_gia.ReadOnly = true;
            this.txt_gia.Size = new System.Drawing.Size(160, 22);
            this.txt_gia.TabIndex = 12;
            this.txt_gia.TextChanged += new System.EventHandler(this.txt_gia_TextChanged);
            // 
            // txt_soseri
            // 
            this.txt_soseri.Location = new System.Drawing.Point(128, 241);
            this.txt_soseri.Name = "txt_soseri";
            this.txt_soseri.ReadOnly = true;
            this.txt_soseri.Size = new System.Drawing.Size(160, 22);
            this.txt_soseri.TabIndex = 11;
            this.txt_soseri.TextChanged += new System.EventHandler(this.txt_soseri_TextChanged);
            // 
            // txt_mausac
            // 
            this.txt_mausac.Location = new System.Drawing.Point(128, 193);
            this.txt_mausac.Name = "txt_mausac";
            this.txt_mausac.ReadOnly = true;
            this.txt_mausac.Size = new System.Drawing.Size(160, 22);
            this.txt_mausac.TabIndex = 10;
            this.txt_mausac.TextChanged += new System.EventHandler(this.txt_mausac_TextChanged);
            // 
            // txt_namsanxuat
            // 
            this.txt_namsanxuat.Location = new System.Drawing.Point(128, 147);
            this.txt_namsanxuat.Name = "txt_namsanxuat";
            this.txt_namsanxuat.ReadOnly = true;
            this.txt_namsanxuat.Size = new System.Drawing.Size(160, 22);
            this.txt_namsanxuat.TabIndex = 9;
            this.txt_namsanxuat.TextChanged += new System.EventHandler(this.txt_namsanxuat_TextChanged);
            // 
            // txt_tenthietbi
            // 
            this.txt_tenthietbi.Location = new System.Drawing.Point(128, 94);
            this.txt_tenthietbi.Name = "txt_tenthietbi";
            this.txt_tenthietbi.ReadOnly = true;
            this.txt_tenthietbi.Size = new System.Drawing.Size(160, 22);
            this.txt_tenthietbi.TabIndex = 13;
            this.txt_tenthietbi.TextChanged += new System.EventHandler(this.txt_tenthietbi_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 16);
            this.label1.TabIndex = 8;
            this.label1.Text = "Tìm theo";
            // 
            // devicesTableAdapter
            // 
            this.devicesTableAdapter.ClearBeforeFill = true;
            // 
            // txt_ban
            // 
            this.txt_ban.Location = new System.Drawing.Point(480, 378);
            this.txt_ban.Name = "txt_ban";
            this.txt_ban.Size = new System.Drawing.Size(167, 22);
            this.txt_ban.TabIndex = 25;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(393, 381);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(31, 16);
            this.label8.TabIndex = 26;
            this.label8.Text = "Seri";
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txt_ban);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btn_ban);
            this.Controls.Add(this.btn_sapxep);
            this.Controls.Add(this.cb_timtheo);
            this.Controls.Add(this.cb_sapxep);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_gia);
            this.Controls.Add(this.txt_soseri);
            this.Controls.Add(this.txt_mausac);
            this.Controls.Add(this.txt_namsanxuat);
            this.Controls.Add(this.txt_tenthietbi);
            this.Controls.Add(this.label1);
            this.Name = "Form5";
            this.Text = "Form5";
            this.Load += new System.EventHandler(this.Form5_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.devicesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.miniprojectDataSet4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btn_ban;
        private System.Windows.Forms.Button btn_sapxep;
        private System.Windows.Forms.ComboBox cb_timtheo;
        private System.Windows.Forms.ComboBox cb_sapxep;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_gia;
        private System.Windows.Forms.TextBox txt_soseri;
        private System.Windows.Forms.TextBox txt_mausac;
        private System.Windows.Forms.TextBox txt_namsanxuat;
        private System.Windows.Forms.TextBox txt_tenthietbi;
        private System.Windows.Forms.Label label1;
        private miniprojectDataSet4 miniprojectDataSet4;
        private System.Windows.Forms.BindingSource devicesBindingSource;
        private miniprojectDataSet4TableAdapters.devicesTableAdapter devicesTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn soseriDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tenthietbiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mausachDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn namsanxuatDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn giaDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox txt_ban;
        private System.Windows.Forms.Label label8;
    }
}