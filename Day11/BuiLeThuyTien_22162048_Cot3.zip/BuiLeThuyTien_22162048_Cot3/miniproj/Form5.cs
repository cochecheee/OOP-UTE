﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace miniproj
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }
        deviceDataContext db = new deviceDataContext();
        private void Form5_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'miniprojectDataSet4.devices' table. You can move, or remove it, as needed.
            this.devicesTableAdapter.Fill(this.miniprojectDataSet4.devices);

            var list = (from s in db.devices select s).ToList();
            dataGridView1.DataSource = list;

        }

        private void cb_timtheo_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if(cb_timtheo.SelectedIndex == 0)
                {
                    txt_tenthietbi.Clear();
                    txt_namsanxuat.Clear();
                    txt_mausac.Clear();
                    txt_soseri.Clear();
                    txt_gia.Clear();

                    txt_tenthietbi.ReadOnly = false;
                    txt_namsanxuat.ReadOnly = true;
                    txt_mausac.ReadOnly = true;
                    txt_soseri.ReadOnly = true;
                    txt_gia.ReadOnly = true;
                    
                }else if (cb_timtheo.SelectedIndex == 1)
                {
                    txt_tenthietbi.Clear();
                    txt_namsanxuat.Clear();
                    txt_mausac.Clear();
                    txt_soseri.Clear();
                    txt_gia.Clear();

                    txt_tenthietbi.ReadOnly = true;
                    txt_namsanxuat.ReadOnly = false;
                    txt_mausac.ReadOnly = true;
                    txt_soseri.ReadOnly = true;
                    txt_gia.ReadOnly = true;

                }else if (cb_timtheo.SelectedIndex == 2)
                {
                    txt_tenthietbi.Clear();
                    txt_namsanxuat.Clear();
                    txt_mausac.Clear();
                    txt_soseri.Clear();
                    txt_gia.Clear();

                    txt_tenthietbi.ReadOnly = true;
                    txt_namsanxuat.ReadOnly = true;
                    txt_mausac.ReadOnly = false;
                    txt_soseri.ReadOnly = true;
                    txt_gia.ReadOnly = true;

                }else if (cb_timtheo.SelectedIndex == 3)
                {
                    txt_tenthietbi.Clear();
                    txt_namsanxuat.Clear();
                    txt_mausac.Clear();
                    txt_soseri.Clear();
                    txt_gia.Clear();

                    txt_tenthietbi.ReadOnly = true;
                    txt_namsanxuat.ReadOnly = true;
                    txt_mausac.ReadOnly = true;
                    txt_soseri.ReadOnly = false;
                    txt_gia.ReadOnly = true;

                }else if (cb_timtheo.SelectedIndex == 4)
                {
                    txt_tenthietbi.Clear();
                    txt_namsanxuat.Clear();
                    txt_mausac.Clear();
                    txt_soseri.Clear();
                    txt_gia.Clear();

                    txt_tenthietbi.ReadOnly = true;
                    txt_namsanxuat.ReadOnly = true;
                    txt_mausac.ReadOnly = true;
                    txt_soseri.ReadOnly = true;
                    txt_gia.ReadOnly = false;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txt_tenthietbi_TextChanged(object sender, EventArgs e)
        {
            var list = (from s in db.devices where s.Tenthietbi.Contains(txt_tenthietbi.Text) select s).ToList();
            dataGridView1.DataSource = list;
        }

        private void txt_namsanxuat_TextChanged(object sender, EventArgs e)
        {
            var list = (from s in db.devices where s.Namsanxuat.Contains(txt_namsanxuat.Text) select s).ToList();
            dataGridView1.DataSource = list;
        }

        private void txt_mausac_TextChanged(object sender, EventArgs e)
        {
            var list = (from s in db.devices where s.Mausach.Contains(txt_mausac.Text) select s).ToList();
            dataGridView1.DataSource = list;
        }

        private void txt_soseri_TextChanged(object sender, EventArgs e)
        {
            var list = (from s in db.devices where s.Soseri.Contains(txt_soseri.Text) select s).ToList();
            dataGridView1.DataSource = list;
        }

        private void txt_gia_TextChanged(object sender, EventArgs e)
        {
            var list = (from s in db.devices where s.Gia.Contains(txt_gia.Text) select s).ToList();
            dataGridView1.DataSource = list;
        }

        private void btn_sapxep_Click(object sender, EventArgs e)
        {
            if(cb_sapxep.SelectedIndex == -1)
            {
                MessageBox.Show("Vui lòng nhấp chọn sắp xếp tăng hay giảm");
                return;
            }else if(cb_sapxep.SelectedIndex == 0)
            {
                //tăng
                var list = db.devices.OrderBy(s => Convert.ToInt32(s.Gia)).ToList();
                dataGridView1.DataSource = list;
            }
            else if (cb_sapxep.SelectedIndex == 1)
            {
                //giảm
                var list = db.devices.OrderByDescending(s => Convert.ToInt32(s.Gia)).ToList();
                dataGridView1.DataSource = list;
            }
        }

        private void btn_ban_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(txt_ban.Text))
            {
                MessageBox.Show("Không có điện thoại này trong hãng.");
                return;
            }
            
            try
            {
                var list = db.devices.Where(s => s.Soseri == txt_ban.Text).FirstOrDefault();

                if (list != null)
                {
                    phonestore phone = new phonestore();
                    phone.Tenthietbi = list.Tenthietbi;
                    phone.Namsanxuat = list.Namsanxuat;
                    phone.Mausac = list.Mausach;
                    phone.Soseri = list.Soseri;
                    phone.Gia = list.Gia;
                    phone.Thangban = DateTime.Now.Month.ToString();

                    phonestoreDataContext ps = new phonestoreDataContext();
                    ps.phonestores.InsertOnSubmit(phone);
                    db.devices.DeleteOnSubmit(list);

                    ps.SubmitChanges();
                    db.SubmitChanges();

                    Form5_Load(sender, e);
                }
                else
                {
                    MessageBox.Show("Không có điện thoại này trong hãng.");
                    return;
                }
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
